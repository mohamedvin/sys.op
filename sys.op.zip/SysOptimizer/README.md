# SysOptimizer Pro

A full system control panel + optimizer for Windows: Dashboard, Applications
manager, Process manager, Storage Analyzer, Optimizer tools, and Settings.

## ⚠️ Important — read this first

This app uses Windows-only APIs (registry, process control, system dialogs),
so the `.exe` **must be built on a Windows PC**. It cannot be cross-compiled
from another OS. The good news: building it yourself takes about 2 minutes
and requires zero coding — just double-click a file.

## How to build your .exe (on Windows)

1. Install Python 3.10+ from https://python.org if you don't have it.
   During install, check **"Add Python to PATH"**.
2. Copy this whole folder to your Windows PC.
3. Double-click **`build.bat`**.
   - It installs the needed packages automatically.
   - It then builds `SysOptimizerPro.exe`.
4. When it finishes, find your program at:
   `dist\SysOptimizerPro.exe`
5. Double-click it to run. Right-click → "Run as administrator" for full
   functionality (uninstalling apps, ending system processes, clearing
   protected temp folders, etc.) — the build already requests admin
   automatically via UAC.

That's it — `SysOptimizerPro.exe` is now a standalone file you can copy
anywhere, no Python needed on the target machine.

## What it does

**Dashboard** — Live CPU, RAM, Disk, GPU gauges, 60-second CPU history graph,
network throughput, disk I/O, uptime, process count.

**Applications** — Lists every installed app (from the Windows registry) with
version, publisher, install path, and size. Search, sort by column, uninstall,
or jump to the install folder.

**Processes** — Live list of every running process with PID, CPU%, RAM usage,
status, and owner. Search and end any process.

**Storage Analyzer** — Per-drive usage bars (used/free/total), plus a large
file scanner that walks any folder/drive and lists everything over 100 MB,
sorted largest-first.

**Optimizer** — One-click tools: Temp Cleaner (wipes TEMP/TMP/Windows\Temp
with a freed-space report), Startup Manager (opens msconfig), Cache Cleaner
(Prefetch + thumbnail cache), Clipboard Clear, RAM working-set flush, and
Disk Cleanup launcher. All actions are timestamped in an on-screen log.

**Settings** — Theme switch (dark/light/system), and quick links to Task
Manager, Control Panel, Device Manager, System Info, Registry Editor, and
Services.

## Notes & honesty about scope

- "GPU Usage" shows a placeholder (0%) unless you install `gputil` or
  `nvidia-ml-py` and wire it in — true cross-vendor GPU monitoring needs
  vendor-specific libraries (NVML for Nvidia, etc.), which I didn't bundle
  to keep the build dependency-light. Let me know if you want NVIDIA-only
  GPU stats added.
- Ending essential system processes can crash Windows — the app doesn't
  block you from this, so be careful with PIDs you don't recognize.
- The large-file scanner walks the entire path you give it, so scanning a
  full drive (e.g. `C:\`) can take a minute or two depending on file count.
- Uninstalling apps runs each program's own uninstaller (same as Control
  Panel does) — it doesn't force-delete files, by design, to avoid leaving
  the registry or system in a broken state.

## Files in this package

- `main.py` — full application source
- `build.bat` — one-click Windows build script
- `requirements.txt` — Python dependencies
