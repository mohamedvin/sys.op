@echo off
title SysOptimizer Pro - Build Script
echo ============================================
echo   SysOptimizer Pro - EXE Builder
echo ============================================
echo.
echo Step 1: Installing required Python packages...
pip install psutil customtkinter pyinstaller pywin32 --quiet
echo.
echo Step 2: Building the .exe (this takes 1-3 minutes)...
pyinstaller --noconfirm --onefile --windowed ^
    --name "SysOptimizerPro" ^
    --icon=NONE ^
    --uac-admin ^
    main.py
echo.
echo ============================================
echo   DONE! Your .exe is in the "dist" folder:
echo   dist\SysOptimizerPro.exe
echo ============================================
pause
