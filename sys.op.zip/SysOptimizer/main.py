"""
SysOptimizer Pro - System Monitor & Optimizer
A comprehensive Windows system control panel and optimizer
"""

import tkinter as tk
from tkinter import ttk, messagebox
import customtkinter as ctk
import psutil
import threading
import time
import os
import subprocess
import shutil
import platform
import glob
from datetime import datetime
import winreg
import ctypes
import sys


# ─── Theme & Colors ───────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

BG_DARK    = "#0D1117"
BG_PANEL   = "#161B22"
BG_CARD    = "#1C2128"
ACCENT     = "#00D4FF"
ACCENT2    = "#7C3AED"
SUCCESS    = "#22C55E"
WARNING    = "#F59E0B"
DANGER     = "#EF4444"
TEXT_PRI   = "#F0F6FC"
TEXT_SEC   = "#8B949E"
BORDER     = "#30363D"


# ─── Helper: is_admin ─────────────────────────────────────────────────────────
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False


def request_admin():
    if not is_admin():
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable, " ".join(sys.argv), None, 1
        )
        sys.exit()


# ─── Circular Gauge Widget ────────────────────────────────────────────────────
class CircularGauge(tk.Canvas):
    def __init__(self, parent, label="", size=130, **kw):
        super().__init__(parent, width=size, height=size,
                         bg=BG_CARD, highlightthickness=0, **kw)
        self.size = size
        self.label = label
        self._value = 0
        self._draw(0)

    def _draw(self, value):
        s = self.size
        self.delete("all")
        pad = 12
        # Background arc
        self.create_arc(pad, pad, s-pad, s-pad,
                        start=135, extent=270,
                        outline=BORDER, width=8, style="arc")
        # Value arc
        color = SUCCESS if value < 60 else (WARNING if value < 85 else DANGER)
        extent = (value / 100) * 270
        self.create_arc(pad, pad, s-pad, s-pad,
                        start=135, extent=extent,
                        outline=color, width=8, style="arc")
        # Center text
        cx, cy = s//2, s//2
        self.create_text(cx, cy-8, text=f"{value:.0f}%",
                         fill=TEXT_PRI, font=("Segoe UI", 16, "bold"))
        self.create_text(cx, cy+14, text=self.label,
                         fill=TEXT_SEC, font=("Segoe UI", 9))

    def set_value(self, v):
        self._value = v
        self._draw(v)


# ─── Stat Card ────────────────────────────────────────────────────────────────
class StatCard(ctk.CTkFrame):
    def __init__(self, parent, title, icon, **kw):
        super().__init__(parent, fg_color=BG_CARD, corner_radius=12,
                         border_width=1, border_color=BORDER, **kw)
        self.gauge = CircularGauge(self, label=icon, size=130)
        self.gauge.pack(pady=(18, 4))
        ctk.CTkLabel(self, text=title, font=("Segoe UI", 12, "bold"),
                     text_color=TEXT_PRI).pack()
        self.val_label = ctk.CTkLabel(self, text="—",
                                      font=("Segoe UI", 10),
                                      text_color=TEXT_SEC)
        self.val_label.pack(pady=(2, 14))

    def update(self, pct, detail=""):
        self.gauge.set_value(pct)
        self.val_label.configure(text=detail)


# ─── Section Header ───────────────────────────────────────────────────────────
def section_header(parent, title, subtitle=""):
    f = ctk.CTkFrame(parent, fg_color="transparent")
    f.pack(fill="x", padx=24, pady=(20, 8))
    ctk.CTkLabel(f, text=title, font=("Segoe UI", 20, "bold"),
                 text_color=TEXT_PRI).pack(anchor="w")
    if subtitle:
        ctk.CTkLabel(f, text=subtitle, font=("Segoe UI", 11),
                     text_color=TEXT_SEC).pack(anchor="w")
    ctk.CTkFrame(parent, height=1, fg_color=BORDER).pack(fill="x",
                                                          padx=24, pady=(0, 16))


# ─── Main Application ─────────────────────────────────────────────────────────
class SysOptimizerApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("SysOptimizer Pro")
        self.geometry("1280x780")
        self.minsize(1100, 680)
        self.configure(fg_color=BG_DARK)

        self._active_section = "dashboard"
        self._stop_monitor = False

        self._build_layout()
        self._show_section("dashboard")

        # Start background monitor
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build_layout(self):
        # Sidebar
        self.sidebar = ctk.CTkFrame(self, width=220, fg_color=BG_PANEL,
                                    corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        # Logo
        logo_f = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        logo_f.pack(fill="x", padx=18, pady=(24, 8))
        ctk.CTkLabel(logo_f, text="⚡ SysOptimizer",
                     font=("Segoe UI", 16, "bold"),
                     text_color=ACCENT).pack(anchor="w")
        ctk.CTkLabel(logo_f, text="Pro Edition",
                     font=("Segoe UI", 10), text_color=TEXT_SEC).pack(anchor="w")

        ctk.CTkFrame(self.sidebar, height=1, fg_color=BORDER).pack(
            fill="x", padx=12, pady=12)

        # Nav buttons
        nav_items = [
            ("dashboard",     "🖥",  "Dashboard"),
            ("applications",  "📦",  "Applications"),
            ("processes",     "⚙️",  "Processes"),
            ("storage",       "💾",  "Storage Analyzer"),
            ("optimizer",     "🚀",  "Optimizer"),
            ("settings",      "⚙",  "Settings"),
        ]
        self._nav_buttons = {}
        for key, icon, label in nav_items:
            btn = ctk.CTkButton(
                self.sidebar, text=f" {icon}  {label}",
                anchor="w", font=("Segoe UI", 13),
                fg_color="transparent", hover_color=BG_CARD,
                text_color=TEXT_PRI, height=44, corner_radius=8,
                command=lambda k=key: self._show_section(k)
            )
            btn.pack(fill="x", padx=12, pady=3)
            self._nav_buttons[key] = btn

        # System info at bottom
        ctk.CTkFrame(self.sidebar, height=1, fg_color=BORDER).pack(
            fill="x", padx=12, pady=12, side="bottom")
        self.bottom_info = ctk.CTkLabel(
            self.sidebar,
            text=f"OS: {platform.system()} {platform.release()}",
            font=("Segoe UI", 9), text_color=TEXT_SEC)
        self.bottom_info.pack(side="bottom", padx=12, pady=(4, 12))

        # Main content
        self.content = ctk.CTkFrame(self, fg_color=BG_DARK, corner_radius=0)
        self.content.pack(side="left", fill="both", expand=True)

        # Build all pages
        self.pages = {}
        self.pages["dashboard"]    = self._build_dashboard()
        self.pages["applications"] = self._build_applications()
        self.pages["processes"]    = self._build_processes()
        self.pages["storage"]      = self._build_storage()
        self.pages["optimizer"]    = self._build_optimizer()
        self.pages["settings"]     = self._build_settings()

    # ── Section Switcher ──────────────────────────────────────────────────────
    def _show_section(self, key):
        self._active_section = key
        for k, btn in self._nav_buttons.items():
            if k == key:
                btn.configure(fg_color=BG_CARD, text_color=ACCENT)
            else:
                btn.configure(fg_color="transparent", text_color=TEXT_PRI)
        for k, page in self.pages.items():
            page.pack_forget()
        self.pages[key].pack(fill="both", expand=True)
        if key == "applications":
            self._load_applications()
        if key == "processes":
            self._refresh_processes()

    # ── Dashboard ─────────────────────────────────────────────────────────────
    def _build_dashboard(self):
        page = ctk.CTkScrollableFrame(self.content, fg_color=BG_DARK,
                                      scrollbar_button_color=BORDER)
        section_header(page, "Dashboard", "Real-time system overview")

        cards_f = ctk.CTkFrame(page, fg_color="transparent")
        cards_f.pack(fill="x", padx=24, pady=8)

        self.cpu_card  = StatCard(cards_f, "CPU",  "CPU")
        self.ram_card  = StatCard(cards_f, "RAM",  "RAM")
        self.disk_card = StatCard(cards_f, "Disk", "HDD")
        self.gpu_card  = StatCard(cards_f, "GPU",  "GPU")

        for c in [self.cpu_card, self.ram_card,
                  self.disk_card, self.gpu_card]:
            c.pack(side="left", padx=10, pady=8)

        # CPU History
        section_header(page, "CPU Usage History", "Last 60 seconds")
        self.history_canvas = tk.Canvas(page, height=120, bg=BG_CARD,
                                        highlightthickness=0)
        self.history_canvas.pack(fill="x", padx=24)
        self._cpu_history = [0] * 60

        # Network + disk IO
        info_f = ctk.CTkFrame(page, fg_color="transparent")
        info_f.pack(fill="x", padx=24, pady=16)

        self.net_card  = self._mini_info_card(info_f, "🌐 Network",
                                               "Upload / Download")
        self.io_card   = self._mini_info_card(info_f, "💿 Disk I/O",
                                               "Read / Write")
        self.boot_card = self._mini_info_card(info_f, "🕐 Uptime",
                                               "System uptime")
        self.proc_card = self._mini_info_card(info_f, "⚙ Processes",
                                               "Running processes")
        for c in [self.net_card, self.io_card,
                  self.boot_card, self.proc_card]:
            c.pack(side="left", padx=10, expand=True, fill="x")

        return page

    def _mini_info_card(self, parent, title, sub):
        f = ctk.CTkFrame(parent, fg_color=BG_CARD, corner_radius=12,
                         border_width=1, border_color=BORDER)
        ctk.CTkLabel(f, text=title, font=("Segoe UI", 13, "bold"),
                     text_color=TEXT_PRI).pack(padx=16, pady=(14, 2))
        lbl = ctk.CTkLabel(f, text=sub, font=("Segoe UI", 10),
                           text_color=TEXT_SEC)
        lbl.pack(padx=16, pady=(0, 14))
        f._val_label = lbl
        return f

    def _draw_cpu_history(self):
        c = self.history_canvas
        c.delete("all")
        w = c.winfo_width()
        if w < 10:
            return
        h = 120
        pts = self._cpu_history
        n = len(pts)
        xs = [int(w * i / (n - 1)) for i in range(n)]
        ys = [int(h - (h * v / 100) - 8) for v in pts]
        # Fill area
        poly = []
        for x, y in zip(xs, ys):
            poly += [x, y]
        poly += [xs[-1], h, xs[0], h]
        c.create_polygon(poly, fill="#00D4FF22", outline="")
        # Line
        for i in range(n - 1):
            c.create_line(xs[i], ys[i], xs[i+1], ys[i+1],
                          fill=ACCENT, width=2)

    # ── Applications ──────────────────────────────────────────────────────────
    def _build_applications(self):
        page = ctk.CTkFrame(self.content, fg_color=BG_DARK)

        header_f = ctk.CTkFrame(page, fg_color="transparent")
        header_f.pack(fill="x", padx=24, pady=(20, 8))
        ctk.CTkLabel(header_f, text="📦 Installed Applications",
                     font=("Segoe UI", 20, "bold"),
                     text_color=TEXT_PRI).pack(side="left")
        self.app_refresh_btn = ctk.CTkButton(
            header_f, text="🔄 Refresh", width=110,
            fg_color=BG_CARD, hover_color=BORDER, text_color=ACCENT,
            border_width=1, border_color=BORDER,
            command=self._load_applications)
        self.app_refresh_btn.pack(side="right")

        self.app_search = ctk.CTkEntry(page, placeholder_text="🔍 Search apps…",
                                       height=38, corner_radius=8)
        self.app_search.pack(fill="x", padx=24, pady=(0, 8))
        self.app_search.bind("<KeyRelease>", lambda e: self._filter_apps())

        ctk.CTkFrame(page, height=1, fg_color=BORDER).pack(
            fill="x", padx=24, pady=(0, 8))

        # Table header
        cols = ("Name", "Version", "Publisher", "Install Path", "Size")
        hdr = ctk.CTkFrame(page, fg_color=BG_PANEL, height=36)
        hdr.pack(fill="x", padx=24)
        widths = [260, 90, 160, 340, 80]
        for col, w in zip(cols, widths):
            ctk.CTkLabel(hdr, text=col, font=("Segoe UI", 11, "bold"),
                         text_color=ACCENT, width=w, anchor="w").pack(
                side="left", padx=8, pady=6)

        # Treeview
        tree_f = ctk.CTkFrame(page, fg_color=BG_DARK)
        tree_f.pack(fill="both", expand=True, padx=24, pady=4)

        style = ttk.Style()
        style.theme_use("default")
        style.configure("Apps.Treeview",
                        background=BG_CARD, foreground=TEXT_PRI,
                        fieldbackground=BG_CARD, rowheight=32,
                        font=("Segoe UI", 10))
        style.configure("Apps.Treeview.Heading",
                        background=BG_PANEL, foreground=ACCENT,
                        font=("Segoe UI", 10, "bold"))
        style.map("Apps.Treeview",
                  background=[("selected", ACCENT2)],
                  foreground=[("selected", TEXT_PRI)])

        self.app_tree = ttk.Treeview(
            tree_f, columns=cols, show="headings",
            style="Apps.Treeview")
        for col, w in zip(cols, widths):
            self.app_tree.heading(col, text=col,
                                  command=lambda c=col: self._sort_apps(c))
            self.app_tree.column(col, width=w, minwidth=60)

        vsb = ttk.Scrollbar(tree_f, orient="vertical",
                             command=self.app_tree.yview)
        self.app_tree.configure(yscrollcommand=vsb.set)
        self.app_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        # Action bar
        act_f = ctk.CTkFrame(page, fg_color=BG_PANEL, height=52)
        act_f.pack(fill="x", padx=24, pady=(4, 16))
        act_f.pack_propagate(False)
        self.app_count_lbl = ctk.CTkLabel(act_f, text="0 apps found",
                                          font=("Segoe UI", 11),
                                          text_color=TEXT_SEC)
        self.app_count_lbl.pack(side="left", padx=16, pady=12)
        ctk.CTkButton(act_f, text="🗑 Uninstall Selected", width=160,
                      fg_color=DANGER, hover_color="#B91C1C",
                      command=self._uninstall_app).pack(
            side="right", padx=12, pady=8)
        ctk.CTkButton(act_f, text="📂 Open Location", width=140,
                      fg_color=BG_CARD, hover_color=BORDER,
                      border_width=1, border_color=BORDER,
                      command=self._open_app_location).pack(
            side="right", padx=4, pady=8)

        self._all_apps = []
        return page

    def _load_applications(self):
        self.app_tree.delete(*self.app_tree.get_children())
        self.app_count_lbl.configure(text="Scanning…")

        def worker():
            apps = []
            paths = [
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
            ]
            for hive in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
                for path in paths:
                    try:
                        key = winreg.OpenKey(hive, path)
                        for i in range(winreg.QueryInfoKey(key)[0]):
                            try:
                                sub = winreg.OpenKey(key, winreg.EnumKey(key, i))
                                def _q(n):
                                    try:
                                        return winreg.QueryValueEx(sub, n)[0]
                                    except Exception:
                                        return ""
                                name = _q("DisplayName")
                                if not name:
                                    continue
                                apps.append({
                                    "name":      name,
                                    "version":   _q("DisplayVersion"),
                                    "publisher": _q("Publisher"),
                                    "path":      _q("InstallLocation"),
                                    "uninstall": _q("UninstallString"),
                                    "size":      _q("EstimatedSize"),
                                })
                            except Exception:
                                pass
                    except Exception:
                        pass
            apps.sort(key=lambda x: x["name"].lower())
            self._all_apps = apps
            self.after(0, self._populate_apps)

        threading.Thread(target=worker, daemon=True).start()

    def _populate_apps(self, apps=None):
        if apps is None:
            apps = self._all_apps
        self.app_tree.delete(*self.app_tree.get_children())
        for a in apps:
            sz = a["size"]
            sz_str = f"{int(sz)//1024} MB" if sz else "—"
            self.app_tree.insert("", "end", values=(
                a["name"], a["version"], a["publisher"],
                a["path"] or "—", sz_str
            ))
        self.app_count_lbl.configure(
            text=f"{len(apps)} app{'s' if len(apps)!=1 else ''} found")

    def _filter_apps(self):
        q = self.app_search.get().lower()
        filtered = [a for a in self._all_apps if q in a["name"].lower()]
        self._populate_apps(filtered)

    def _sort_apps(self, col):
        items = [(self.app_tree.set(k, col), k)
                 for k in self.app_tree.get_children("")]
        items.sort()
        for idx, (_, k) in enumerate(items):
            self.app_tree.move(k, "", idx)

    def _uninstall_app(self):
        sel = self.app_tree.selection()
        if not sel:
            messagebox.showinfo("Select App",
                                "Please select an application first.")
            return
        name = self.app_tree.item(sel[0])["values"][0]
        app = next((a for a in self._all_apps
                    if a["name"] == name), None)
        if not app or not app.get("uninstall"):
            messagebox.showerror("Error",
                "No uninstall command found for this application.")
            return
        if messagebox.askyesno("Confirm Uninstall",
                               f"Uninstall '{name}'?"):
            subprocess.Popen(app["uninstall"], shell=True)

    def _open_app_location(self):
        sel = self.app_tree.selection()
        if not sel:
            return
        path = self.app_tree.item(sel[0])["values"][3]
        if path and path != "—" and os.path.exists(path):
            os.startfile(path)
        else:
            messagebox.showinfo("Path Not Found",
                                "Install path not found or not available.")

    # ── Processes ─────────────────────────────────────────────────────────────
    def _build_processes(self):
        page = ctk.CTkFrame(self.content, fg_color=BG_DARK)

        hdr_f = ctk.CTkFrame(page, fg_color="transparent")
        hdr_f.pack(fill="x", padx=24, pady=(20, 8))
        ctk.CTkLabel(hdr_f, text="⚙️ Running Processes",
                     font=("Segoe UI", 20, "bold"),
                     text_color=TEXT_PRI).pack(side="left")
        ctk.CTkButton(hdr_f, text="🔄 Refresh", width=110,
                      fg_color=BG_CARD, hover_color=BORDER,
                      text_color=ACCENT, border_width=1, border_color=BORDER,
                      command=self._refresh_processes).pack(side="right")

        self.proc_search = ctk.CTkEntry(
            page, placeholder_text="🔍 Search processes…",
            height=38, corner_radius=8)
        self.proc_search.pack(fill="x", padx=24, pady=(0, 8))
        self.proc_search.bind("<KeyRelease>",
                              lambda e: self._filter_processes())

        ctk.CTkFrame(page, height=1, fg_color=BORDER).pack(
            fill="x", padx=24, pady=(0, 4))

        cols = ("PID", "Name", "CPU %", "RAM (MB)", "Status", "User")
        style = ttk.Style()
        style.configure("Proc.Treeview",
                        background=BG_CARD, foreground=TEXT_PRI,
                        fieldbackground=BG_CARD, rowheight=30,
                        font=("Segoe UI", 10))
        style.configure("Proc.Treeview.Heading",
                        background=BG_PANEL, foreground=ACCENT,
                        font=("Segoe UI", 10, "bold"))
        style.map("Proc.Treeview",
                  background=[("selected", ACCENT2)],
                  foreground=[("selected", TEXT_PRI)])

        tree_f = ctk.CTkFrame(page, fg_color=BG_DARK)
        tree_f.pack(fill="both", expand=True, padx=24, pady=4)

        self.proc_tree = ttk.Treeview(
            tree_f, columns=cols, show="headings",
            style="Proc.Treeview")
        widths = [70, 220, 90, 100, 90, 150]
        for col, w in zip(cols, widths):
            self.proc_tree.heading(col, text=col)
            self.proc_tree.column(col, width=w)

        vsb2 = ttk.Scrollbar(tree_f, orient="vertical",
                              command=self.proc_tree.yview)
        self.proc_tree.configure(yscrollcommand=vsb2.set)
        self.proc_tree.pack(side="left", fill="both", expand=True)
        vsb2.pack(side="right", fill="y")

        act_f = ctk.CTkFrame(page, fg_color=BG_PANEL, height=52)
        act_f.pack(fill="x", padx=24, pady=(4, 16))
        act_f.pack_propagate(False)
        self.proc_count_lbl = ctk.CTkLabel(act_f, text="",
                                           font=("Segoe UI", 11),
                                           text_color=TEXT_SEC)
        self.proc_count_lbl.pack(side="left", padx=16)
        ctk.CTkButton(act_f, text="❌ End Process", width=140,
                      fg_color=DANGER, hover_color="#B91C1C",
                      command=self._end_process).pack(
            side="right", padx=12, pady=8)

        self._all_procs = []
        return page

    def _refresh_processes(self):
        procs = []
        for p in psutil.process_iter(
                ['pid', 'name', 'cpu_percent', 'memory_info',
                 'status', 'username']):
            try:
                info = p.info
                ram_mb = info['memory_info'].rss / 1024**2 if info['memory_info'] else 0
                procs.append((
                    info['pid'],
                    info['name'] or "—",
                    info['cpu_percent'],
                    round(ram_mb, 1),
                    info['status'] or "—",
                    (info['username'] or "—").split("\\")[-1]
                ))
            except Exception:
                pass
        procs.sort(key=lambda x: x[3], reverse=True)
        self._all_procs = procs
        self._populate_procs(procs)

    def _populate_procs(self, procs):
        self.proc_tree.delete(*self.proc_tree.get_children())
        for p in procs:
            self.proc_tree.insert("", "end", values=p)
        self.proc_count_lbl.configure(
            text=f"{len(procs)} processes")

    def _filter_processes(self):
        q = self.proc_search.get().lower()
        filtered = [p for p in self._all_procs
                    if q in str(p[1]).lower()]
        self._populate_procs(filtered)

    def _end_process(self):
        sel = self.proc_tree.selection()
        if not sel:
            messagebox.showinfo("Select Process",
                                "Please select a process first.")
            return
        pid  = int(self.proc_tree.item(sel[0])["values"][0])
        name = self.proc_tree.item(sel[0])["values"][1]
        if messagebox.askyesno("End Process",
                               f"End process '{name}' (PID {pid})?"):
            try:
                psutil.Process(pid).terminate()
                self._refresh_processes()
            except Exception as e:
                messagebox.showerror("Error", str(e))

    # ── Storage Analyzer ──────────────────────────────────────────────────────
    def _build_storage(self):
        page = ctk.CTkScrollableFrame(self.content, fg_color=BG_DARK,
                                      scrollbar_button_color=BORDER)
        section_header(page, "💾 Storage Analyzer",
                       "Drives, folders, and large files")

        # Drives
        drive_f = ctk.CTkFrame(page, fg_color="transparent")
        drive_f.pack(fill="x", padx=24, pady=8)
        self._build_drive_cards(drive_f)

        # Large files scanner
        scan_f = ctk.CTkFrame(page, fg_color=BG_CARD, corner_radius=12,
                              border_width=1, border_color=BORDER)
        scan_f.pack(fill="x", padx=24, pady=12)

        hdr2 = ctk.CTkFrame(scan_f, fg_color="transparent")
        hdr2.pack(fill="x", padx=16, pady=(14, 8))
        ctk.CTkLabel(hdr2, text="🔍 Large File Scanner",
                     font=("Segoe UI", 14, "bold"),
                     text_color=TEXT_PRI).pack(side="left")

        ctrl = ctk.CTkFrame(scan_f, fg_color="transparent")
        ctrl.pack(fill="x", padx=16, pady=4)
        self.scan_path = ctk.CTkEntry(ctrl, placeholder_text="C:\\",
                                      height=36, corner_radius=8)
        self.scan_path.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.scan_btn = ctk.CTkButton(ctrl, text="▶ Scan", width=90,
                                      command=self._scan_large_files)
        self.scan_btn.pack(side="left")

        self.scan_status = ctk.CTkLabel(scan_f, text="",
                                        font=("Segoe UI", 10),
                                        text_color=TEXT_SEC)
        self.scan_status.pack(padx=16, pady=4, anchor="w")

        self.large_tree = self._make_tree(
            scan_f,
            ("File", "Size", "Location"),
            (340, 100, 380))
        self.large_tree.pack(fill="x", padx=16, pady=(0, 14))

        return page

    def _build_drive_cards(self, parent):
        for part in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(part.mountpoint)
            except Exception:
                continue
            total_gb = usage.total / 1024**3
            used_gb  = usage.used  / 1024**3
            free_gb  = usage.free  / 1024**3
            pct      = usage.percent

            card = ctk.CTkFrame(parent, fg_color=BG_CARD,
                                corner_radius=12, border_width=1,
                                border_color=BORDER)
            card.pack(side="left", padx=8, ipadx=8, ipady=8)

            ctk.CTkLabel(card,
                         text=f"💽 {part.mountpoint}  [{part.fstype}]",
                         font=("Segoe UI", 13, "bold"),
                         text_color=TEXT_PRI).pack(padx=16, pady=(12, 4))

            bar_color = SUCCESS if pct < 70 else (WARNING if pct < 90 else DANGER)
            ctk.CTkProgressBar(card, width=200, height=12,
                               progress_color=bar_color,
                               fg_color=BORDER).set(pct / 100)
            ctk.CTkProgressBar(card, width=200, height=12,
                               progress_color=bar_color,
                               fg_color=BORDER).pack(padx=16, pady=4)

            ctk.CTkLabel(card,
                         text=f"Used: {used_gb:.1f} GB / {total_gb:.1f} GB  ({pct}%)",
                         font=("Segoe UI", 10), text_color=TEXT_SEC).pack(
                padx=16, pady=(0, 4))
            ctk.CTkLabel(card,
                         text=f"Free: {free_gb:.1f} GB",
                         font=("Segoe UI", 10), text_color=SUCCESS).pack(
                padx=16, pady=(0, 12))

    def _make_tree(self, parent, cols, widths):
        style = ttk.Style()
        style.configure("Gen.Treeview",
                        background=BG_DARK, foreground=TEXT_PRI,
                        fieldbackground=BG_DARK, rowheight=28,
                        font=("Segoe UI", 10))
        style.configure("Gen.Treeview.Heading",
                        background=BG_PANEL, foreground=ACCENT,
                        font=("Segoe UI", 10, "bold"))
        style.map("Gen.Treeview",
                  background=[("selected", ACCENT2)],
                  foreground=[("selected", TEXT_PRI)])
        tree = ttk.Treeview(parent, columns=cols, show="headings",
                            style="Gen.Treeview", height=10)
        for col, w in zip(cols, widths):
            tree.heading(col, text=col)
            tree.column(col, width=w)
        return tree

    def _scan_large_files(self):
        path = self.scan_path.get() or "C:\\"
        if not os.path.exists(path):
            messagebox.showerror("Invalid Path", f"Path not found: {path}")
            return
        self.scan_btn.configure(state="disabled", text="Scanning…")
        self.scan_status.configure(text="Scanning… this may take a moment")
        self.large_tree.delete(*self.large_tree.get_children())

        def worker():
            results = []
            try:
                for dirpath, dirnames, filenames in os.walk(path):
                    for fn in filenames:
                        try:
                            fp = os.path.join(dirpath, fn)
                            sz = os.path.getsize(fp)
                            if sz > 100 * 1024 * 1024:  # > 100 MB
                                results.append((fn, sz, dirpath))
                        except Exception:
                            pass
            except Exception:
                pass
            results.sort(key=lambda x: x[1], reverse=True)
            self.after(0, lambda: self._populate_large(results))

        threading.Thread(target=worker, daemon=True).start()

    def _populate_large(self, results):
        self.large_tree.delete(*self.large_tree.get_children())
        for fn, sz, loc in results[:200]:
            sz_str = f"{sz/1024**3:.2f} GB" if sz > 1e9 else f"{sz/1024**2:.0f} MB"
            self.large_tree.insert("", "end", values=(fn, sz_str, loc))
        self.scan_status.configure(
            text=f"Found {len(results)} large files (>100 MB)")
        self.scan_btn.configure(state="normal", text="▶ Scan")

    # ── Optimizer ─────────────────────────────────────────────────────────────
    def _build_optimizer(self):
        page = ctk.CTkScrollableFrame(self.content, fg_color=BG_DARK,
                                      scrollbar_button_color=BORDER)
        section_header(page, "🚀 Optimizer",
                       "Clean temp files, manage startup, clear caches")

        # Quick clean cards
        tasks = [
            ("🗑  Temp Cleaner",
             "Remove Windows temporary files\nand user temp folder contents.",
             self._clean_temp, WARNING),
            ("🔄  Startup Manager",
             "View and disable startup\nprograms to speed up boot.",
             self._open_startup, ACCENT2),
            ("🧹  Cache Cleaner",
             "Clear browser caches, thumbnails,\nand prefetch data.",
             self._clean_cache, SUCCESS),
            ("📋  Clipboard Clear",
             "Clear the Windows clipboard\ncontent immediately.",
             self._clear_clipboard, ACCENT),
            ("🪟  RAM Flush",
             "Encourage Windows to free up\nunused RAM (working set).",
             self._flush_ram, WARNING),
            ("🔍  Disk Cleanup",
             "Open Windows built-in\nDisk Cleanup utility.",
             self._disk_cleanup, TEXT_SEC),
        ]

        grid_f = ctk.CTkFrame(page, fg_color="transparent")
        grid_f.pack(fill="x", padx=24, pady=8)

        for i, (title, desc, cmd, color) in enumerate(tasks):
            card = ctk.CTkFrame(grid_f, fg_color=BG_CARD,
                                corner_radius=14, border_width=1,
                                border_color=BORDER)
            row, col = divmod(i, 3)
            card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")
            grid_f.columnconfigure(col, weight=1)

            ctk.CTkLabel(card, text=title,
                         font=("Segoe UI", 13, "bold"),
                         text_color=TEXT_PRI).pack(padx=16, pady=(16, 6))
            ctk.CTkLabel(card, text=desc,
                         font=("Segoe UI", 10),
                         text_color=TEXT_SEC, justify="left").pack(
                padx=16, pady=(0, 12))
            ctk.CTkButton(card, text="Run", fg_color=color,
                          hover_color=color, command=cmd,
                          width=100, height=32).pack(pady=(0, 16))

        # Log
        ctk.CTkLabel(page, text="Optimizer Log",
                     font=("Segoe UI", 13, "bold"),
                     text_color=TEXT_PRI).pack(padx=24, anchor="w",
                                               pady=(12, 4))
        self.opt_log = ctk.CTkTextbox(page, height=180,
                                      font=("Consolas", 10),
                                      fg_color=BG_CARD)
        self.opt_log.pack(fill="x", padx=24, pady=(0, 20))
        self.opt_log.insert("end", "Ready. Choose an optimization task above.\n")
        self.opt_log.configure(state="disabled")

        return page

    def _log(self, msg):
        self.opt_log.configure(state="normal")
        self.opt_log.insert("end",
                            f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")
        self.opt_log.see("end")
        self.opt_log.configure(state="disabled")

    def _clean_temp(self):
        def worker():
            removed = 0
            freed   = 0
            dirs = [
                os.environ.get("TEMP", ""),
                os.environ.get("TMP", ""),
                r"C:\Windows\Temp",
            ]
            for d in dirs:
                if not d or not os.path.exists(d):
                    continue
                for item in os.listdir(d):
                    fp = os.path.join(d, item)
                    try:
                        if os.path.isfile(fp):
                            freed += os.path.getsize(fp)
                            os.remove(fp)
                            removed += 1
                        elif os.path.isdir(fp):
                            freed += sum(
                                os.path.getsize(os.path.join(r, f))
                                for r, ds, fs in os.walk(fp) for f in fs
                                if os.path.exists(os.path.join(r, f)))
                            shutil.rmtree(fp, ignore_errors=True)
                            removed += 1
                    except Exception:
                        pass
            freed_mb = freed / 1024**2
            self.after(0, lambda: self._log(
                f"✅ Temp clean done: {removed} items, {freed_mb:.1f} MB freed"))
        self._log("⏳ Cleaning temp files…")
        threading.Thread(target=worker, daemon=True).start()

    def _open_startup(self):
        subprocess.Popen("msconfig", shell=True)
        self._log("✅ Opened System Configuration (Startup tab)")

    def _clean_cache(self):
        def worker():
            freed = 0
            # Prefetch
            for fp in glob.glob(r"C:\Windows\Prefetch\*"):
                try:
                    freed += os.path.getsize(fp)
                    os.remove(fp)
                except Exception:
                    pass
            # Thumbnails
            th = os.path.expanduser(
                r"~\AppData\Local\Microsoft\Windows\Explorer")
            for fp in glob.glob(os.path.join(th, "thumbcache_*.db")):
                try:
                    freed += os.path.getsize(fp)
                    os.remove(fp)
                except Exception:
                    pass
            freed_mb = freed / 1024**2
            self.after(0, lambda: self._log(
                f"✅ Cache cleared: {freed_mb:.1f} MB freed"))
        self._log("⏳ Clearing caches…")
        threading.Thread(target=worker, daemon=True).start()

    def _clear_clipboard(self):
        try:
            self.clipboard_clear()
            self._log("✅ Clipboard cleared")
        except Exception as e:
            self._log(f"❌ Error: {e}")

    def _flush_ram(self):
        self._log("⏳ Flushing RAM working set…")
        try:
            for p in psutil.process_iter(['pid']):
                try:
                    handle = ctypes.windll.kernel32.OpenProcess(
                        0x1F0FFF, False, p.pid)
                    if handle:
                        ctypes.windll.psapi.EmptyWorkingSet(handle)
                        ctypes.windll.kernel32.CloseHandle(handle)
                except Exception:
                    pass
            self._log("✅ RAM working sets flushed")
        except Exception as e:
            self._log(f"❌ Error: {e}")

    def _disk_cleanup(self):
        subprocess.Popen("cleanmgr", shell=True)
        self._log("✅ Opened Windows Disk Cleanup")

    # ── Settings ──────────────────────────────────────────────────────────────
    def _build_settings(self):
        page = ctk.CTkScrollableFrame(self.content, fg_color=BG_DARK,
                                      scrollbar_button_color=BORDER)
        section_header(page, "⚙ Settings", "Appearance and preferences")

        sects = [
            ("Appearance", [
                ("Theme", ["Dark", "Light", "System"], self._set_theme),
            ]),
            ("Quick Links", []),
        ]

        for sect_title, items in sects:
            s_f = ctk.CTkFrame(page, fg_color=BG_CARD, corner_radius=12,
                               border_width=1, border_color=BORDER)
            s_f.pack(fill="x", padx=24, pady=8)
            ctk.CTkLabel(s_f, text=sect_title,
                         font=("Segoe UI", 13, "bold"),
                         text_color=ACCENT).pack(padx=16, pady=(14, 6),
                                                 anchor="w")
            for label, opts, cmd in items:
                row = ctk.CTkFrame(s_f, fg_color="transparent")
                row.pack(fill="x", padx=16, pady=6)
                ctk.CTkLabel(row, text=label,
                             font=("Segoe UI", 11),
                             text_color=TEXT_PRI).pack(side="left")
                ctk.CTkOptionMenu(row, values=opts,
                                  command=cmd).pack(side="right")
            ctk.CTkFrame(s_f, height=6, fg_color="transparent").pack()

        # Quick links
        links_f = ctk.CTkFrame(page, fg_color=BG_CARD, corner_radius=12,
                               border_width=1, border_color=BORDER)
        links_f.pack(fill="x", padx=24, pady=8)
        ctk.CTkLabel(links_f, text="Quick System Links",
                     font=("Segoe UI", 13, "bold"),
                     text_color=ACCENT).pack(padx=16, pady=(14, 8), anchor="w")
        link_grid = ctk.CTkFrame(links_f, fg_color="transparent")
        link_grid.pack(padx=16, pady=(0, 14))
        links = [
            ("Task Manager",    "taskmgr"),
            ("Control Panel",   "control"),
            ("Device Manager",  "devmgmt.msc"),
            ("System Info",     "msinfo32"),
            ("Registry Editor", "regedit"),
            ("Services",        "services.msc"),
        ]
        for i, (label, cmd) in enumerate(links):
            r, c = divmod(i, 3)
            ctk.CTkButton(link_grid, text=label, width=160,
                          fg_color=BG_DARK, border_width=1,
                          border_color=BORDER, hover_color=BORDER,
                          command=lambda c=cmd: subprocess.Popen(
                              c, shell=True)).grid(
                row=r, column=c, padx=6, pady=4)

        # About
        about_f = ctk.CTkFrame(page, fg_color=BG_CARD, corner_radius=12,
                               border_width=1, border_color=BORDER)
        about_f.pack(fill="x", padx=24, pady=8)
        info = [
            f"SysOptimizer Pro v1.0",
            f"Python {platform.python_version()} · psutil {psutil.__version__}",
            f"OS: {platform.system()} {platform.release()} ({platform.machine()})",
            f"Host: {platform.node()}",
        ]
        for line in info:
            ctk.CTkLabel(about_f, text=line, font=("Segoe UI", 10),
                         text_color=TEXT_SEC).pack(padx=16, pady=2,
                                                   anchor="w")
        ctk.CTkFrame(about_f, height=8, fg_color="transparent").pack()

        return page

    def _set_theme(self, val):
        ctk.set_appearance_mode(val.lower())

    # ── Background Monitor ────────────────────────────────────────────────────
    def _monitor_loop(self):
        _prev_net = psutil.net_io_counters()
        _prev_io  = psutil.disk_io_counters()
        while not self._stop_monitor:
            try:
                cpu  = psutil.cpu_percent(interval=1)
                ram  = psutil.virtual_memory()
                disk = psutil.disk_usage("/")

                # CPU history
                self._cpu_history.append(cpu)
                if len(self._cpu_history) > 60:
                    self._cpu_history.pop(0)

                # Net
                net  = psutil.net_io_counters()
                up   = (net.bytes_sent - _prev_net.bytes_sent) / 1024
                down = (net.bytes_recv - _prev_net.bytes_recv) / 1024
                _prev_net = net

                # Disk IO
                io   = psutil.disk_io_counters()
                read  = (io.read_bytes  - _prev_io.read_bytes)  / 1024**2
                write = (io.write_bytes - _prev_io.write_bytes) / 1024**2
                _prev_io = io

                uptime = int(time.time() - psutil.boot_time())
                h, rem = divmod(uptime, 3600)
                m, s   = divmod(rem, 60)
                uptime_str = f"{h}h {m}m {s}s"
                nproc  = len(psutil.pids())

                # GPU (rough estimate via CPU if no GPU lib)
                gpu_pct = 0.0

                def _update():
                    # Cards
                    self.cpu_card.update(
                        cpu, f"{cpu:.1f}% · {psutil.cpu_count()} cores")
                    self.ram_card.update(
                        ram.percent,
                        f"{ram.used/1024**3:.1f} / {ram.total/1024**3:.1f} GB")
                    self.disk_card.update(
                        disk.percent,
                        f"{disk.used/1024**3:.1f} / {disk.total/1024**3:.1f} GB")
                    self.gpu_card.update(
                        gpu_pct, "No GPU lib installed")
                    # Mini cards
                    self.net_card._val_label.configure(
                        text=f"↑ {up:.0f} KB/s  ↓ {down:.0f} KB/s")
                    self.io_card._val_label.configure(
                        text=f"R {read:.1f} MB/s  W {write:.1f} MB/s")
                    self.boot_card._val_label.configure(text=uptime_str)
                    self.proc_card._val_label.configure(
                        text=f"{nproc} processes")
                    # History chart
                    self._draw_cpu_history()

                self.after(0, _update)
            except Exception:
                pass
            time.sleep(1)

    def on_close(self):
        self._stop_monitor = True
        self.destroy()


# ─── Entry Point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = SysOptimizerApp()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()
